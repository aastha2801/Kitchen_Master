package com.example.kitchen_master_demo

object setData {

    const val name:String = "name"
    const val score:String = "score"

    fun getQuestion():ArrayList<QuestionData>{
        var que:ArrayList<QuestionData> = arrayListOf()

        var q1 = QuestionData(
            1,
            "How much water do you need to cook rice?(For each cup of rice)",
            "1 cup",
            "2 cups",
            "3 cups",
            "1/3 cup",
            2
        )

        var q2 = QuestionData(
            2,
            "How do you preserve nutrients when cooking veggies?",
            "cook them...",
            "freeze them...",
            "steam them...",
            "nothing...",
            3
        )

        var q3 = QuestionData(
            3,
            "What makes cakes turn brown?",
            "eggs",
            "Sugar",
            "Milk",
            "Baking Soda",
            4
        )

        var q4 = QuestionData(
            4,
            "What’s the best way to boil pasta?",
            "Boil them as usual",
            "add salt first, then boil",
            "start with cold water, add salt",
            "add salt and 1tbs oil when boilling",
            3
        )

        var q5 = QuestionData(
            5,
            "What removes onion scent from hands?",
            "lemon juice",
            "orange juice",
            "beat root",
            "ginger juice",
            1
        )

        var q6 = QuestionData(
            6,
            "Unbaked cookie dough can be covered and refrigerated for up to how many hours?",
            "12 hours",
            "2 days",
            "6 hours",
            "1 day",
            4
        )

        var q7 = QuestionData(
            7,
            "Which is the most stolen food in the world?",
            "Butter",
            "Cheese",
            "Onions",
            "Carrots",
            2
        )

        var q8 = QuestionData(
            8,
            "How many tablespoons are in 1/2 cup?",
            "4",
            "6",
            "8",
            "3",
            3
        )

        var q9 = QuestionData(
            9,
            "What is the boiling point of water?",
            "212 degrees Fahrenheit",
            "240 degrees Fahrenheit",
            "175 degrees Fahrenheit",
            "305 degrees Fahrenheit",
            1
        )

        var q10 = QuestionData(
            10,
            "Food shouldn't be left out of the refrigerator for more than...",
            "6 hours",
            "2 hours",
            "4 hours",
            "5 hours",
            2
        )
        que.add(q1)
        que.add(q2)
        que.add(q3)
        que.add(q4)
        que.add(q5)
        que.add(q6)
        que.add(q7)
        que.add(q8)
        que.add(q9)
        que.add(q10)
        return que

    }
}