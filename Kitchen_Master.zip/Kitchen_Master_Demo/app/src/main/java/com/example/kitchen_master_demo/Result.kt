package com.example.kitchen_master_demo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_result.*

class Result : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
        val userName = intent.getStringExtra(setData.name)
        val score = intent.getStringExtra(setData.score)
        val totalQuestion = intent.getStringExtra("total size")

        name_text.text = "Congratulations ${userName} !!"
        score_text.text = "${score} / ${totalQuestion}"



        val sharedPreferences: SharedPreferences = this.getSharedPreferences("mypref", Context.MODE_PRIVATE)

        val Name = findViewById<TextView>(R.id.name_text)
        val Score = findViewById<TextView>(R.id.score_text)

        finish_btn.setOnClickListener {
            // startActivity(Intent(this, MainActivity::class.java))
            // finish()

            var n:String = Name.text.toString()
            var s:String = Score.text.toString()

            val editor:SharedPreferences.Editor =  sharedPreferences.edit()
            editor.putString("name_key",n)
            editor.putString("score_key",s)

            editor.apply()

            Toast.makeText(this, " score saved", Toast.LENGTH_SHORT).show()
        }

    }
}