package com.example.kitchen_master_demo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.view.Gravity
import android.widget.Toast


class CallReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent!!.getStringExtra(TelephonyManager.EXTRA_STATE) == TelephonyManager.EXTRA_STATE_OFFHOOK
        )
        {
            showToastMsg(context!!,"Phone call is started")
        }else if (
            intent.getStringExtra(TelephonyManager.EXTRA_STATE) == TelephonyManager.EXTRA_STATE_IDLE
        ){
            showToastMsg(context!!,"Phone call is ended")
        }else if (
            intent.getStringExtra(TelephonyManager.EXTRA_STATE) == TelephonyManager.EXTRA_STATE_RINGING
        ){
            showToastMsg(context!!,"Incoming call")
        }
    }
    fun showToastMsg(c:Context, msg:String){
        var toast = Toast.makeText(c,msg, Toast.LENGTH_LONG)
        toast.setGravity(Gravity.CENTER,0,0)
        toast.show()
    }
}